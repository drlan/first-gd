# This file was automatically generated from renpy/gl/__init__.py
# Modifications will be automatically overwritten.
